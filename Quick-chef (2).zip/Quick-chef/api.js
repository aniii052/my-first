// Simple API Helper Functions
const API_URL = 'http://localhost:3000';

// Recipes
async function getAllRecipes() {
    try {
        const response = await fetch(`${API_URL}/recipes`);
        return await response.json();
    } catch (error) {
        console.error('Error loading recipes:', error);
        return [];
    }
}

async function getRecipeById(id) {
    try {
        const response = await fetch(`${API_URL}/recipes/${id}`);
        return await response.json();
    } catch (error) {
        console.error('Error loading recipe:', error);
        return null;
    }
}

// Grocery Items
async function getAllGroceryItems() {
    try {
        const response = await fetch(`${API_URL}/groceryItems`);
        return await response.json();
    } catch (error) {
        console.error('Error loading grocery items:', error);
        return [];
    }
}

// Cart
async function getCart() {
    try {
        const response = await fetch(`${API_URL}/cart`);
        return await response.json();
    } catch (error) {
        console.error('Error loading cart:', error);
        return [];
    }
}

async function addToCartAPI(item) {
    try {
        const response = await fetch(`${API_URL}/cart, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(item)
        }`);
        return await response.json();
    } catch (error) {
        console.error('Error adding to cart:', error);
        return null;
    }
}

async function deleteFromCart(id) {
    try {
        await fetch(`${API_URL}/cart/${id}, {
            method: 'DELETE'
        }`);
        return true;
    } catch (error) {
        console.error('Error deleting from cart:', error);
        return false;
    }
}

// Users
async function registerUserAPI(userData) {
    try {
        const response = await fetch(`${API_URL}/users, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        }`);
        return await response.json();
    } catch (error) {
        console.error('Error registering user:', error);
        return null;
    }
}