// Complete Recipe Database with Detailed Instructions
const recipes = [
    {
        id: 1,
        name: "Butter Chicken",
        cuisine: "indian",
        prepTime: "45 min",
        difficulty: "Medium",
        image:"butterchicken.jpg",
        emoji: "🍛",
        servings: 4,
        ingredients: ["500g boneless chicken", "1 cup heavy cream", "2 tbsp butter", "1 large onion", "3 tomatoes", "4 garlic cloves", "1 inch ginger", "2 tbsp tomato paste", "Spices (cumin, coriander, garam masala)", "1/2 cup yogurt", "Salt", "Fresh cilantro"],
        mood: "comfort",
        instructions: "Marinate chicken with yogurt and spices for 2 hours. Cook chicken until 80% done. Sauté onions, add ginger-garlic, tomato paste, and spices. Add pureed tomatoes, then cooked chicken. Simmer with cream for 10 minutes. Garnish with cilantro.",
        detailedSteps: [
            "Marinate chicken pieces with yogurt, half the ginger-garlic, red chili powder, and salt for 2 hours.",
            "Heat oil in a pan and cook marinated chicken until 80% done. Remove and set aside.",
            "In the same pan, melt butter and sauté onions until golden brown.",
            "Add remaining ginger-garlic paste and cook for 1 minute.",
            "Add tomato paste and cook for 2 minutes until oil separates.",
            "Add pureed tomatoes and cook for 5-7 minutes until thick.",
            "Add all spices and cook for 2 minutes.",
            "Add cooked chicken and mix well. Cook for 5 minutes.",
            "Pour in heavy cream and simmer for 10 minutes on low heat.",
            "Adjust seasoning and garnish with fresh cilantro. Serve hot with rice."
        ]
    },
    {
        id: 2,
        name: "Chicken Biryani",
        cuisine: "indian",
        prepTime: "90 min",
        difficulty: "Hard",
        emoji: "🍚",
        image:"chickenbiryani.jpg",
        servings: 6,
        ingredients: ["750g basmati rice", "1kg chicken", "2 large onions", "1 cup yogurt", "4 tbsp ghee", "Whole spices (cardamom, bay leaves, cinnamon)", "Biryani masala", "Mint leaves", "Fried onions", "Saffron", "Salt"],
        mood: "comfort",
        instructions: "Soak rice for 30 minutes. Marinate chicken with yogurt and spices. Layer partially cooked rice over chicken. Add fried onions, mint, and saffron. Cook on dum for 45 minutes.",
        detailedSteps: [
            "Wash and soak basmati rice for 30 minutes, then drain.",
            "Marinate chicken with yogurt, red chili powder, turmeric, biryani masala, and salt for 1 hour.",
            "Heat ghee in a heavy-bottomed pot. Add cumin seeds and whole spices.",
            "Add marinated chicken and cook until 70% done. Remove and set aside.",
            "Boil water with whole spices and salt. Add rice and cook until 70% done.",
            "Layer the partially cooked rice over chicken in the pot.",
            "Sprinkle fried onions, mint leaves, and saffron milk on top.",
            "Cover with foil, then place lid tightly. Cook on high for 3 minutes.",
            "Reduce to lowest heat, place pot on tawa and cook for 45 minutes.",
            "Rest for 10 minutes, then gently mix and serve with raita."
        ]
    },
    {
        id: 3,
        name: "Dal Tadka",
        cuisine: "indian",
        prepTime: "30 min",
        difficulty: "Easy",
        emoji: "🍲",
        image:"Dal-Tadka.jpg",
        servings: 4,
        ingredients: ["1 cup yellow lentils", "2 tomatoes", "1 onion", "2 green chilies", "1 tsp turmeric", "1 tsp cumin seeds", "4-5 garlic cloves", "1 inch ginger", "2 tbsp ghee", "Fresh cilantro", "Salt"],
        mood: "comfort",
        instructions: "Pressure cook dal with turmeric. Make tadka with cumin seeds, ginger-garlic, onions, and tomatoes. Mix with cooked dal and simmer.",
        detailedSteps: [
            "Wash and pressure cook dal with turmeric and salt for 3-4 whistles.",
            "Mash the cooked dal and keep aside.",
            "Heat ghee in pan. Add cumin and mustard seeds.",
            "Add minced ginger-garlic and green chilies. Sauté for 1 minute.",
            "Add onions and cook until translucent.",
            "Add tomatoes and cook until they break down.",
            "Pour the cooked dal into this tempering.",
            "Simmer for 5-7 minutes. Garnish with cilantro and serve."
        ]
    },
    {
        id: 4,
        name: "Chicken Fried Rice",
        cuisine: "chinese",
        prepTime: "25 min",
        difficulty: "Easy",
        emoji: "🍚",
        image:"chickenfriedrice",
        servings: 4,
        ingredients: ["3 cups cooked rice", "300g chicken breast", "2 eggs", "1 carrot", "1/2 cup green peas", "3 spring onions", "3 garlic cloves", "2 tbsp soy sauce", "1 tbsp oyster sauce", "Sesame oil", "Vegetable oil"],
        mood: "quick",
        instructions: "Scramble eggs and set aside. Stir-fry chicken, then vegetables. Add rice and sauces. Mix in eggs and spring onions.",
        detailedSteps: [
            "Heat oil in wok. Scramble eggs and remove from pan.",
            "Stir-fry diced chicken until cooked through.",
            "Add garlic, carrots, and peas. Stir-fry for 2-3 minutes.",
            "Add cooked rice and break up clumps.",
            "Add soy sauce, oyster sauce, and sesame oil.",
            "Return eggs to pan and mix gently.",
            "Add spring onions and serve immediately."
        ]
    },
    {
        id: 5,
        name: "Margherita Pizza",
        cuisine: "italian",
        prepTime: "45 min",
        difficulty: "Medium",
        emoji: "🍕",
        image:"pizza.jpeg",
        servings: 4,
        ingredients: ["2 cups all-purpose flour", "1 tsp yeast", "3/4 cup warm water", "2 tbsp olive oil", "1 tsp salt", "1/2 cup pizza sauce", "200g mozzarella", "Fresh basil", "2 tomatoes"],
        mood: "comfort",
        instructions: "Make dough with flour, yeast, and water. Let rise for 1 hour. Roll out, add sauce, cheese, and tomatoes. Bake at 475°F for 12-15 minutes.",
        detailedSteps: [
            "Mix warm water, sugar, and yeast. Let foam for 5 minutes.",
            "Combine flour and salt, add yeast mixture and oil.",
            "Knead for 8-10 minutes until smooth. Let rise for 1 hour.",
            "Preheat oven to 475°F. Roll out dough.",
            "Spread sauce, add mozzarella and tomato slices.",
            "Bake for 12-15 minutes until golden.",
            "Top with fresh basil before serving."
        ]
    },
    {
        id: 6,
        name: "Pasta Carbonara",
        cuisine: "italian",
        prepTime: "25 min",
        difficulty: "Medium",
        emoji: "🍝",
        image:"pasta.jpeg",
        servings: 4,
        ingredients: ["400g spaghetti", "200g pancetta", "4 egg yolks", "1 whole egg", "1 cup Pecorino Romano", "2 garlic cloves", "Black pepper", "Salt"],
        mood: "comfort",
        instructions: "Cook pasta. Sauté pancetta with garlic. Mix eggs and cheese. Combine hot pasta with pancetta, then quickly mix in egg mixture off heat.",
        detailedSteps: [
            "Cook spaghetti until al dente. Reserve pasta water.",
            "Sauté pancetta until crispy, add garlic.",
            "Whisk egg yolks, whole egg, and cheese with black pepper.",
            "Add hot pasta to pancetta pan.",
            "Remove from heat, quickly mix in egg mixture.",
            "Add pasta water to create creamy sauce.",
            "Serve immediately with extra cheese and pepper."
        ]
    },
    {
        id: 7,
        name: "Chicken Tacos",
        cuisine: "mexican",
        prepTime: "20 min",
        difficulty: "Easy",
        emoji: "🌮",
        image:"taco.jpeg",
        servings: 4,
        ingredients: ["500g chicken breast", "8 corn tortillas", "1 onion", "2 tomatoes", "1 avocado", "1 lime", "1/2 cup cilantro", "Spices (cumin, chili powder, paprika)", "Sour cream"],
        mood: "quick",
        instructions: "Season and cook chicken with spices. Warm tortillas. Prepare toppings. Assemble tacos with chicken and fresh toppings.",
        detailedSteps: [
            "Season chicken with cumin, chili powder, paprika, salt, and pepper.",
            "Cook chicken until done, then slice into strips.",
            "Warm tortillas in dry pan.",
            "Dice onions and tomatoes, slice avocado.",
            "Assemble tacos with chicken and toppings.",
            "Serve with lime wedges and sour cream."
        ]
    },
    {
        id: 8,
        name: "Chocolate Lava Cake",
        cuisine: "italian",
        prepTime: "25 min",
        difficulty: "Medium",
        emoji: "🍰",
        image:"chocolava.jpg",
        servings: 4,
        ingredients: ["100g dark chocolate", "100g butter", "2 eggs", "2 egg yolks", "1/4 cup sugar", "2 tbsp flour", "Cocoa powder", "Vanilla ice cream"],
        mood: "sweet",
        instructions: "Melt chocolate and butter. Mix with eggs and sugar. Add flour. Bake in greased ramekins at 425°F for 12-14 minutes until edges are firm but center is soft.",
        detailedSteps: [
            "Preheat oven to 425°F. Grease ramekins with butter and dust with cocoa.",
            "Melt chocolate and butter until smooth.",
            "Whisk eggs, egg yolks, and sugar until thick.",
            "Add melted chocolate mixture, then fold in flour.",
            "Divide among ramekins and bake 12-14 minutes.",
            "Let cool for 1 minute, then invert onto plates.",
            "Serve immediately with vanilla ice cream."
        ]
    },
    {
        id: 9,
        name: "Maggi Masala Noodles",
        cuisine: "chinese",
        prepTime: "5 min",
        difficulty: "Easy",
        emoji: "🍜",
        image:"magginoodles.jpg",
        servings: 1,
        ingredients: ["1 pack Maggi noodles", "1 masala packet", "2 cups water", "1 tbsp oil", "Mixed vegetables (optional)", "1 green chili", "Fresh cilantro"],
        mood: "quick",
        instructions: "Boil water, add noodles and cook for 2 minutes. Add masala packet and vegetables. Cook for 1 more minute.",
        detailedSteps: [
            "Boil 2 cups water in a pan.",
            "Add oil and mixed vegetables if using.",
            "Add Maggi noodles and cook for 2 minutes.",
            "Add masala packet and chopped green chili.",
            "Stir well and cook for another minute.",
            "Garnish with fresh cilantro and serve hot."
        ]
    },
    {
        id: 10,
        name: "Avocado Toast",
        cuisine: "american",
        prepTime: "5 min",
        difficulty: "Easy",
        emoji: "🥑",
        image:"Bean-avocado-toast-3.jpg",
        servings: 2,
        ingredients: ["2 slices whole grain bread", "1 ripe avocado", "1 tbsp lemon juice", "1 tomato", "Salt and pepper", "Red pepper flakes", "Olive oil"],
        mood: "healthy",
        instructions: "Toast bread. Mash avocado with lemon juice. Spread on toast, top with tomato slices and seasonings.",
        detailedSteps: [
            "Toast bread slices until golden brown.",
            "Mash avocado with lemon juice, salt, and pepper.",
            "Spread mashed avocado on toast.",
            "Top with tomato slices.",
            "Sprinkle with red pepper flakes and drizzle with olive oil.",
            "Serve immediately."
        ]
    },
    {
        id: 11,
        name: "Green Smoothie",
        cuisine: "american",
        prepTime: "5 min",
        difficulty: "Easy",
        emoji: "🥤",
        image:"green-smoothie-recipe-2.jpg",
        servings: 2,
        ingredients: ["1 banana", "1 cup spinach", "1/2 avocado", "1 cup almond milk", "1 tbsp honey", "1 tbsp chia seeds", "Ice cubes"],
        mood: "healthy",
        instructions: "Blend all ingredients until smooth. Add ice for desired consistency.",
        detailedSteps: [
            "Add banana, spinach, and avocado to blender.",
            "Pour in almond milk and add honey.",
            "Add chia seeds and ice cubes.",
            "Blend on high for 60 seconds until completely smooth.",
            "Taste and adjust sweetness if needed.",
            "Serve immediately in chilled glasses."
        ]
    },
    {
        id: 12,
        name: "Paneer Butter Masala",
        cuisine: "indian",
        prepTime: "30 min",
        difficulty: "Medium",
        emoji: "🧀",
        image:"paneer_buttermasala.jpg",
        servings: 4,
        ingredients: ["400g paneer cubes", "2 tbsp butter", "1 large onion", "3 tomatoes", "1/2 cup cashews", "1/4 cup cream", "Spices (garam masala, red chili powder)", "Fresh cilantro"],
        mood: "comfort",
        instructions: "Soak cashews. Make tomato-cashew gravy. Add paneer cubes and simmer with butter and cream.",
        detailedSteps: [
            "Soak cashews in hot water for 15 minutes.",
            "Blend tomatoes and soaked cashews into smooth paste.",
            "Heat butter in pan, sauté onions until golden.",
            "Add tomato-cashew paste and cook for 10 minutes.",
            "Add spices and cook for 2 minutes.",
            "Add paneer cubes and cream, simmer for 5 minutes.",
            "Garnish with cilantro and serve with naan or rice."
        ]
    },
    {
        id: 13,
        name: "Manchurian",
        cuisine: "chinese",
        prepTime: "80 min",
        difficulty: "easy",
        emoji: "🍚",
        image:"manchurain.jpeg",
        servings: 6,
        ingredients: ["750g basmati rice", "1kg chicken", "2 large onions", "1 cup yogurt", "4 tbsp ghee", "Whole spices (cardamom, bay leaves, cinnamon)", "Biryani masala", "Mint leaves", "Fried onions", "Saffron", "Salt"],
        mood: "comfort",
        instructions: "Manchurian can be prepared either as a dry appetizer or with gravy to serve as a main course.",
        detailedSteps: [
            "part 1: Make the manchurian balls",
            "Prepare vegetables: Finely chop or grate cabbage, carrots, spring onions, and bell peppers. You can also add ginger, garlic, and green chili.",
            " Mix ingredients: Combine the chopped vegetables in a large bowl. Add cornflour (cornstarch), all-purpose flour (maida), salt, and pepper.",
            " Form the dough: Mix everything thoroughly until a sticky 'dough' forms. The natural moisture from the vegetables should be enough to bind the mixture. Avoid kneading, which can make the balls dense. If the mixture is too wet, add a little more flour.",
            " Roll balls: Shape the mixture into small, bite-sized balls.",
            "Deep-fry: Heat oil in a pan over medium-high heat. Fry the balls in batches until they are golden brown and crispy on the outside. Do not overcrowd the pan. Drain excess oil on a paper towel. ",
            "Part 2: Prepare the Manchurian sauce",
            "Sauté aromatics: In a wok or pan, heat 1–2 tablespoons of oil. Add finely chopped garlic and ginger, along with chopped green chilies. Sauté quickly over high heat until fragrant.",
            "Add vegetables: Add chopped onions and bell peppers (optional) to the wok. Stir-fry for a couple of minutes until they are slightly tender but still crisp.",
            "Mix sauces: Combine soy sauce, tomato ketchup, chili sauce, and vinegar in a small bowl.",
            "Add to wok: Pour the sauce mixture into the wok with the aromatics and vegetables. Stir well to combine.Create cornflour slurry: In a separate bowl, mix 1 tablespoon of cornflour with 2 tablespoons of water. This slurry will be used to thicken the sauce.",
            "Thicken the sauce: Add water or vegetable stock to the wok and bring the mixture to a boil. Pour in the cornflour slurry, stirring constantly to prevent lumps. Continue to cook until the sauce thickens and becomes glossy.",
            "Season: Add salt and black pepper to taste. You can also add a pinch of sugar to balance the flavors. ",
            "Part 3: Combine and serve Add balls: Add the fried Manchurian balls to the sauce and toss gently to coat them evenly.",
            "Garnish and serve: Garnish with chopped spring onion greens and serve immediately to maintain crispiness. Enjoy it hot with noodles or fried rice."
        ]
    },
    {
 id: 14,
 name: "Chole Bhature",
 cuisine: "indian",
 prepTime: "45 min",
 difficulty: "Medium",
 emoji: "🍛",
 image:"chole_bhature.jpeg",
 servings: 4,
 ingredients: [
   "2 cups boiled chickpeas",
   "2 onions", "3 tomatoes",
   "Spices (chole masala, turmeric, chili)",
   "Maida dough for bhature",
   "Oil"
 ],
 mood: "comfort",
 instructions: "Cook spicy chole gravy and fry bhature until puffed.",
 detailedSteps: [
   "Sauté onions and tomatoes.",
   "Add spices and chickpeas.",
   "Cook for 15 minutes.",
   "Prepare dough and roll bhature.",
   "Deep fry until puffed.",
   "Serve hot."
 ]
},
{
 id: 15,
 name: "Masala Dosa",
 cuisine: "indian",
 prepTime: "35 min",
 difficulty: "Medium",
 emoji: "🥞",
 image:"masala_dosa.jpeg",
 servings: 3,
 ingredients: [
   "Dosa batter",
   "4 potatoes",
   "Mustard seeds",
   "Curry leaves",
   "Onions",
   "Spices (turmeric, chili powder)"
 ],
 mood: "healthy",
 instructions: "Make crispy dosa and fill with spicy potato stuffing.",
 detailedSteps: [
   "Boil potatoes and mash.",
   "Sauté onions with spices.",
   "Add mashed potatoes.",
   "Spread dosa batter on tawa.",
   "Fill with potato mixture."
 ]
},
{
 id: 16,
 name: "Burrito Bowl",
 cuisine: "mexican",
 prepTime: "20 min",
 difficulty: "Easy",
 emoji: "🥙",
 image:"burrito_bowl.jpeg",
 servings: 2,
 ingredients: [
   "Rice",
   "Beans",
   "Corn",
   "Chicken/Paneer",
   "Salsa",
   "Guacamole"
 ],
 mood: "healthy",
 instructions: "Layer rice, beans and veggies into a bowl.",
 detailedSteps: [
   "Cook rice.",
   "Sauté protein.",
   "Mix beans & corn.",
   "Assemble with salsa & guac."
 ]
},
{
 id: 17,
 name: "Alfredo Pasta",
 cuisine: "italian",
 prepTime: "20 min",
 difficulty: "Easy",
 emoji: "🍝",
 image:"alfredo_pasta.jpeg",
 servings: 2,
 ingredients: [
   "Pasta",
   "Butter",
   "Garlic",
   "Cream",
   "Parmesan cheese"
 ],
 mood: "comfort",
 instructions: "Cook pasta and toss in creamy Alfredo sauce.",
 detailedSteps: [
   "Boil pasta.",
   "Cook garlic in butter.",
   "Add cream & cheese.",
   "Mix pasta."
 ]
},
{
 id: 18,
 name: "Aloo Paratha",
 cuisine: "indian",
 prepTime: "30 min",
 difficulty: "Medium",
 emoji: "🥟",
 image:"aloo_paratha.jpeg",
 servings: 3,
 ingredients: [
   "Wheat dough",
   "Boiled potatoes",
   "Green chilies",
   "Masala (jeera, chili, amchur)",
   "Ghee"
 ],
 mood: "comfort",
 instructions: "Stuff spiced potato filling and cook paratha with ghee.",
 detailedSteps: [
   "Mash potatoes with spices.",
   "Stuff inside dough ball.",
   "Roll and roast with ghee."
 ]
},
{
 id: 19,
 name: "Cheesy Nachos",
 cuisine: "mexican",
 prepTime: "15 min",
 difficulty: "Easy",
 emoji: "🧀",
 image:"nachos.jpeg",
 servings: 2,
 ingredients: [
   "Nacho chips",
   "Cheese sauce",
   "Jalapeños",
   "Salsa"
 ],
 mood: "quick",
 instructions: "Layer nachos with cheese and salsa.",
 detailedSteps: [
   "Heat cheese sauce.",
   "Arrange nachos.",
   "Top with sauce & jalapeños."
 ]
},
{
 id: 20,
 name: "Quesadilla",
 cuisine: "mexican",
 prepTime: "10 min",
 difficulty: "Easy",
 emoji: "🫓",
 image:"quesadilla.jpeg",
 servings: 2,
 ingredients: [
   "Tortillas",
   "Cheese",
   "Onions",
   "Bell peppers"
 ],
 mood: "quick",
 instructions: "Fill tortillas with cheese and grill.",
 detailedSteps: [
   "Sauté veggies.",
   "Add cheese.",
   "Fold tortilla & grill."
 ]
},
{
 id: 21,
 name: "Chili Paneer",
 cuisine: "chinese",
 prepTime: "25 min",
 difficulty: "Medium",
 emoji: "🌶️",
 image:"chili_paneer.jpeg",
 servings: 3,
 ingredients: [
   "Paneer cubes",
   "Soy sauce",
   "Capsicum",
   "Spring onion",
   "Cornflour",
   "Chili sauce"
 ],
 mood: "comfort",
 instructions: "Fry paneer and toss in spicy Chinese sauce.",
 detailedSteps: [
   "Coat paneer with cornflour & fry.",
   "Stir-fry veggies.",
   "Add sauces.",
   "Mix paneer & toss."
 ]
},
{
 id: 22,
 name: "Tomato Basil Pasta",
 cuisine: "italian",
 prepTime: "20 min",
 difficulty: "Easy",
 emoji: "🍅",
 image:"tomato_basil_pasta.jpg",
 servings: 2,
 ingredients: [
   "Pasta",
   "Tomatoes",
   "Garlic",
   "Basil",
   "Olive oil"
 ],
 mood: "quick",
 instructions: "Cook pasta and toss in fresh tomato basil sauce.",
 detailedSteps: [
   "Sauté garlic.",
   "Add tomato puree.",
   "Mix pasta & basil."
 ]
},

{
 id: 23,
 name: "Garlic Bread",
 cuisine: "italian",
 prepTime: "12 min",
 difficulty: "Easy",
 emoji: "🧄",
 image:"garlic_bread.jpeg",
 servings: 2,
 ingredients: [
   "Baguette slices",
   "Butter",
   "Garlic",
   "Parsley"
 ],
 mood: "quick",
 instructions: "Spread garlic butter on bread and bake.",
 detailedSteps: [
   "Mix butter & garlic.",
   "Apply on bread.",
   "Bake 6–8 minutes."
 ]
},
{
 id: 24,
 name: "Rajma Chawal",
 cuisine: "indian",
 prepTime: "40 min",
 difficulty: "Medium",
 emoji: "🍛",
 image:"rajma_chawal.jpeg",
 servings: 4,
 ingredients: [
   "2 cups rajma (kidney beans)",
   "Onions",
   "Tomatoes",
   "Ginger-garlic paste",
   "Rajma masala",
   "Rice"
 ],
 mood: "comfort",
 instructions: "Cook creamy rajma gravy and serve with steamed rice.",
 detailedSteps: [
   "Soak rajma overnight and boil.",
   "Sauté onions & tomatoes.",
   "Add spices and rajma.",
   "Simmer 15 minutes.",
   "Serve with rice."
 ]
},

{
 id: 25,
 name: "Palak Paneer",
 cuisine: "indian",
 prepTime: "25 min",
 difficulty: "Easy",
 emoji: "🥬",
 image:"palak_paneer.jpg",
 servings: 3,
 ingredients: [
   "200g paneer",
   "2 cups spinach",
   "Garlic",
   "Green chilies",
   "Cream",
   "Spices"
 ],
 mood: "healthy",
 instructions: "Blend blanched spinach and cook with paneer cubes.",
 detailedSteps: [
   "Blanch spinach and blend.",
   "Sauté garlic.",
   "Add spinach puree & spices.",
   "Mix paneer & simmer."
 ]
},

{
 id: 26,
 name: "Kadai Paneer",
 cuisine: "indian",
 prepTime: "22 min",
 difficulty: "Easy",
 emoji: "🍲",
 image:"kadai_paneer.jpg",
 servings: 3,
 ingredients: [
   "Paneer cubes",
   "Capsicum",
   "Tomatoes",
   "Onions",
   "Kadai masala"
 ],
 mood: "comfort",
 instructions: "Cook paneer with roasted kadai masala and capsicum.",
 detailedSteps: [
   "Roast masalas & grind.",
   "Sauté onions & capsicum.",
   "Add tomato gravy.",
   "Mix paneer & cook 5 min."
 ]
},

{
 id: 27,
 name: "Poha",
 cuisine: "indian",
 prepTime: "12 min",
 difficulty: "Easy",
 emoji: "🥣",
 image:"poha.jpg",
 servings: 2,
 ingredients: [
   "Flattened rice (poha)",
   "Peanuts",
   "Mustard seeds",
   "Curry leaves",
   "Lemon",
   "Onion"
 ],
 mood: "healthy",
 instructions: "Light and quick breakfast made with poha and tadka.",
 detailedSteps: [
   "Wash and drain poha.",
   "Make tadka with mustard & curry leaves.",
   "Add onions & peanuts.",
   "Mix poha & serve with lemon."
 ]
},

{
 id: 28,
 name: "Sambar",
 cuisine: "indian",
 prepTime: "30 min",
 difficulty: "Easy",
 emoji: "🍲",
 image:"sambar.jpeg",
 servings: 4,
 ingredients: [
   "Toor dal",
   "Tamarind",
   "Drumstick",
   "Tomatoes",
   "Sambar powder"
 ],
 mood: "healthy",
 instructions: "Dal-based curry cooked with veggies and tamarind.",
 detailedSteps: [
   "Boil dal.",
   "Cook veggies with tamarind.",
   "Add sambar powder.",
   "Mix dal & simmer."
 ]
},

{
 id: 29,
 name: "Paneer Tikka",
 cuisine: "indian",
 prepTime: "20 min",
 difficulty: "Easy",
 emoji: "🔥",
 image:"paneer_tikka.jpeg",
 servings: 3,
 ingredients: [
   "Paneer cubes",
   "Curd",
   "Red chili",
   "Garam masala",
   "Capsicum & onion"
 ],
 mood: "quick",
 instructions: "Marinate paneer and grill till smoky.",
 detailedSteps: [
   "Prepare curd marinade.",
   "Mix veggies & paneer.",
   "Grill or tawa roast."
 ]
},

{
 id: 30,
 name: "Chole",
 cuisine: "indian",
 prepTime: "35 min",
 difficulty: "Medium",
 emoji: "🍛",
 image:"chole.jpg",
 servings: 4,
 ingredients: [
   "Boiled chickpeas",
   "Onion",
   "Tomato",
   "Chole masala",
   "Tea bag (optional)"
 ],
 mood: "comfort",
 instructions: "Cook spicy Punjabi-style chickpea curry.",
 detailedSteps: [
   "Sauté onion-tomato paste.",
   "Add masalas & chickpeas.",
   "Simmer for 15 min."
 ]
},

{
 id: 31,
 name: "Idli",
 cuisine: "indian",
 prepTime: "15 min (+ fermentation)",
 difficulty: "Easy",
 emoji: "🍥",
 image:"idli.jpeg",
 servings: 4,
 ingredients: [
   "Idli batter",
   "Oil for greasing"
 ],
 mood: "healthy",
 instructions: "Steam soft fluffy idlis and serve with chutney.",
 detailedSteps: [
   "Pour batter into mould.",
   "Steam for 10 minutes.",
   "Serve with sambar."
 ]
},

{
 id: 32,
 name: "Aloo Tikki",
 cuisine: "indian",
 prepTime: "20 min",
 difficulty: "Easy",
 emoji: "🥔",
 image:"aloo_tikki.jpeg",
 servings: 3,
 ingredients: [
   "Boiled potatoes",
   "Cornflour",
   "Spices",
   "Oil"
 ],
 mood: "comfort",
 instructions: "Crispy potato patties shallow-fried on tawa.",
 detailedSteps: [
   "Mash potatoes with masala.",
   "Shape tikkis.",
   "Shallow fry till golden."
 ]
}


];

// Enhanced Grocery Items Database
const groceryItems = [
    { id: 1, name: "Chicken Breast", price: 250, emoji: "🍗", category: "meat", unit: "500g" },
    { id: 2, name: "Basmati Rice", price: 120, emoji: "🍚", category: "grains", unit: "1kg" },
    { id: 3, name: "Fresh Tomatoes", price: 40, emoji: "🍅", category: "vegetables", unit: "500g" },
    { id: 4, name: "Onions", price: 30, emoji: "🧅", category: "vegetables", unit: "1kg" },
    { id: 5, name: "Fresh Milk", price: 60, emoji: "🥛", category: "dairy", unit: "1L" },
    { id: 6, name: "Butter", price: 90, emoji: "🧈", category: "dairy", unit: "200g" },
    { id: 7, name: "Eggs", price: 80, emoji: "🥚", category: "dairy", unit: "12 pieces" },
    { id: 8, name: "Bread Loaf", price: 35, emoji: "🍞", category: "bakery", unit: "400g" },
    { id: 9, name: "Potatoes", price: 25, emoji: "🥔", category: "vegetables", unit: "1kg" },
    { id: 10, name: "Paneer", price: 120, emoji: "🧀", category: "dairy", unit: "200g" },
    { id: 11, name: "Bell Peppers", price: 60, emoji: "🫑", category: "vegetables", unit: "250g" },
    { id: 12, name: "Garlic", price: 20, emoji: "🧄", category: "vegetables", unit: "100g" },
    { id: 13, name: "Ginger", price: 25, emoji: "🫚", category: "vegetables", unit: "100g" },
    { id: 14, name: "Green Chilies", price: 15, emoji: "🌶️", category: "vegetables", unit: "100g" },
    { id: 15, name: "Cilantro", price: 10, emoji: "🌿", category: "herbs", unit: "1 bunch" },
    { id: 16, name: "Spinach", price: 20, emoji: "🥬", category: "vegetables", unit: "250g" },
    { id: 17, name: "Yogurt", price: 50, emoji: "🍶", category: "dairy", unit: "400g" },
    { id: 18, name: "Heavy Cream", price: 80, emoji: "🥛", category: "dairy", unit: "200ml" },
    { id: 19, name: "Ghee", price: 150, emoji: "🧈", category: "dairy", unit: "200ml" },
    { id: 20, name: "Cumin Seeds", price: 30, emoji: "🌰", category: "spices", unit: "50g" },
    { id: 21, name: "Turmeric Powder", price: 25, emoji: "💛", category: "spices", unit: "100g" },
    { id: 22, name: "Red Chili Powder", price: 40, emoji: "🌶️", category: "spices", unit: "100g" },
    { id: 23, name: "Garam Masala", price: 60, emoji: "🌿", category: "spices", unit: "50g" },
    { id: 24, name: "Pasta", price: 55, emoji: "🍝", category: "grains", unit: "500g" },
    { id: 25, name: "Olive Oil", price: 180, emoji: "🫒", category: "oils", unit: "500ml" },
    { id: 26, name: "Soy Sauce", price: 65, emoji: "🥢", category: "sauces", unit: "200ml" },
    { id: 27, name: "Mozzarella Cheese", price: 200, emoji: "🧀", category: "dairy", unit: "200g" },
    { id: 28, name: "All Purpose Flour", price: 40, emoji: "🌾", category: "grains", unit: "1kg" },
    { id: 29, name: "Dark Chocolate", price: 150, emoji: "🍫", category: "sweets", unit: "100g" },
    { id: 30, name: "Avocado", price: 80, emoji: "🥑", category: "fruits", unit: "2 pieces" }
];

// EXPANDED Language Translations
const translations = {
    en: {
        app_name: "QuickChef",
        home: "Home",
        recipes: "Recipes",
        grocery: "Cart",
        store: "Store",
        login: "Login",
        register: "Register",
        welcome: "Welcome to QuickChef",
        tagline: "Recipe Discovery Meets Instant Grocery Delivery",
        explore_recipes: "Explore Recipes",
        order_groceries: "Order Groceries",
        mood_heading: "What's Your Mood Today?",
        comfort_food: "Comfort Food",
        comfort_desc: "Hearty meals for cozy days",
        quick_meals: "5-Min Meals",
        quick_desc: "Quick fixes for busy times",
        sweet_tooth: "Sweet Tooth",
        sweet_desc: "Desserts and sweet treats",
        healthy_choice: "Healthy Choice",
        healthy_desc: "Nutritious and balanced meals",
        recipe_explorer: "Recipe Explorer",
        search_ingredients: "Search by Ingredients:",
        cuisine: "Cuisine:",
        all_cuisines: "All Cuisines",
        indian: "Indian",
        chinese: "Chinese",
        italian: "Italian",
        mexican: "Mexican",
        search_btn: "Search",
        your_cart: "Your Cart",
        subtotal: "Subtotal:",
        delivery: "Delivery:",
        total: "Total:",
        checkout: "Proceed to Checkout",
        grocery_store: "Grocery Store",
        search_products: "Search products...",
        all: "All",
        vegetables: "Vegetables",
        fruits: "Fruits",
        dairy: "Dairy",
        grains: "Grains",
        add_to_cart: "Add to Cart",
        cook_now: "Cook Now",
        get_ingredients: "Get Ingredients",
        servings: "Servings",
        prep_time: "Prep Time",
        difficulty: "Difficulty",
        easy: "Easy",
        medium: "Medium",
        hard: "Hard"
    },
    hi: {
        app_name: "क्विकशेफ",
        home: "होम",
        recipes: "रेसिपी",
        grocery: "कार्ट",
        store: "स्टोर",
        login: "लॉगिन",
        register: "रजिस्टर",
        welcome: "क्विकशेफ में आपका स्वागत है",
        tagline: "रेसिपी खोज और तुरंत किराना डिलीवरी",
        explore_recipes: "रेसिपी खोजें",
        order_groceries: "किराना ऑर्डर करें",
        mood_heading: "आज आपका मूड कैसा है?",
        comfort_food: "कम्फर्ट फूड",
        comfort_desc: "आरामदायक दिनों के लिए भरपेट भोजन",
        quick_meals: "5 मिनट भोजन",
        quick_desc: "व्यस्त समय के लिए झटपट व्यंजन",
        sweet_tooth: "मीठा खाना",
        sweet_desc: "डेसर्ट और मिठाइयाँ",
        healthy_choice: "स्वस्थ विकल्प",
        healthy_desc: "पौष्टिक और संतुलित भोजन",
        recipe_explorer: "रेसिपी एक्सप्लोरर",
        search_ingredients: "सामग्री से खोजें:",
        cuisine: "व्यंजन:",
        all_cuisines: "सभी व्यंजन",
        indian: "भारतीय",
        chinese: "चीनी",
        italian: "इतालवी",
        mexican: "मैक्सिकन",
        search_btn: "खोजें",
        your_cart: "आपका कार्ट",
        subtotal: "उपयोग:",
        delivery: "डिलीवरी:",
        total: "कुल:",
        checkout: "चेकआउट करें",
        grocery_store: "किराना स्टोर",
        search_products: "उत्पाद खोजें...",
        all: "सभी",
        vegetables: "सब्जियां",
        fruits: "फल",
        dairy: "डेयरी",
        grains: "अनाज",
        add_to_cart: "कार्ट में जोड़ें",
        cook_now: "अभी पकाएं",
        get_ingredients: "सामग्री प्राप्त करें",
        servings: "सर्विंग्स",
        prep_time: "तैयारी समय",
        difficulty: "कठिनाई",
        easy: "आसान",
        medium: "मध्यम",
        hard: "कठिन"
    },
    or: {
        app_name: "କ୍ୱିକଶେଫ",
        home: "ଘର",
        recipes: "ରେସିପି",
        grocery: "କାର୍ଟ",
        store: "ଦୋକାନ",
        login: "ଲଗଇନ",
        register: "ରେଜିଷ୍ଟର",
        welcome: "କ୍ୱିକଶେଫକୁ ସ୍ୱାଗତ",
        tagline: "ରେସିପି ଆବିଷ୍କାର ଏବଂ ତୁରନ୍ତ କିରାଣା ଡେଲିଭରି",
        explore_recipes: "ରେସିପି ଖୋଜନ୍ତୁ",
        order_groceries: "କିରାଣା ଅର୍ଡର କରନ୍ତୁ",
        mood_heading: "ଆଜି ଆପଣଙ୍କ ମୁଡ୍ କ'ଣ?",
        comfort_food: "ଆରାମ ଖାଦ୍ୟ",
        comfort_desc: "ଆରାମଦାୟକ ଦିନ ପାଇଁ ଭରପୂର ଭୋଜନ",
        quick_meals: "୫ ମିନିଟ୍ ଭୋଜନ",
        quick_desc: "ବ୍ୟସ୍ତ ସମୟ ପାଇଁ ଶୀଘ୍ର ଖାଦ୍ୟ",
        sweet_tooth: "ମିଠା ଖାଇବାକୁ",
        sweet_desc: "ଡେଜର୍ଟ ଏବଂ ମିଠା",
        healthy_choice: "ସ୍ୱାସ୍ଥ୍ୟକର ବିକଳ୍ପ",
        healthy_desc: "ପୁଷ୍ଟିକର ଏବଂ ସନ୍ତୁଳିତ ଭୋଜନ",
        recipe_explorer: "ରେସିପି ଏକ୍ସପ୍ଲୋରର",
        search_ingredients: "ଉପାଦାନ ଦ୍ୱାରା ଖୋଜନ୍ତୁ:",
        cuisine: "ରୋଷେଇ:",
        all_cuisines: "ସମସ୍ତ ରୋଷେଇ",
        indian: "ଭାରତୀୟ",
        chinese: "ଚାଇନିଜ୍",
        italian: "ଇଟାଲିୟାନ୍",
        mexican: "ମେକ୍ସିକାନ୍",
        search_btn: "ଖୋଜନ୍ତୁ",
        your_cart: "ଆପଣଙ୍କ କାର୍ଟ",
        subtotal: "ଉପମୋଟ:",
        delivery: "ଡେଲିଭରି:",
        total: "ମୋଟ:",
        checkout: "ଚେକଆଉଟ୍ କରନ୍ତୁ",
        grocery_store: "କିରାଣା ଦୋକାନ",
        search_products: "ଉତ୍ପାଦ ଖୋଜନ୍ତୁ...",
        all: "ସମସ୍ତ",
        vegetables: "ପନିପରିବା",
        fruits: "ଫଳ",
        dairy: "ଦୁଗ୍ଧଜାତ",
        grains: "ଶସ୍ୟ",
        add_to_cart: "କାର୍ଟରେ ଯୋଗ କରନ୍ତୁ",
        cook_now: "ବର୍ତ୍ତମାନ ରାନ୍ଧନ୍ତୁ",
        get_ingredients: "ଉପାଦାନ ପାଆନ୍ତୁ",
        servings: "ସର୍ଭିଂସ୍",
        prep_time: "ପ୍ରସ୍ତୁତି ସମୟ",
        difficulty: "କଠିନତା",
        easy: "ସହଜ",
        medium: "ମଧ୍ୟମ",
        hard: "କଠିନ"
    }
};

// Global Variables
let cart = [];
let currentUser = null;
let currentLanguage = 'en';
let filteredRecipes = [...recipes];
let filteredGroceries = [...groceryItems];

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
    updateLanguage();
    displayRecipes(recipes);
    displayGroceryItems(groceryItems);
    updateCartDisplay();
});

// Authentication Functions
function openAuthModal(type) {
    document.getElementById('authModal').style.display = 'block';
    if (type === 'register') {
        switchToRegister();
    } else {
        switchToLogin();
    }
}

function closeAuthModal() {
    document.getElementById('authModal').style.display = 'none';
}

function switchToLogin() {
    document.getElementById('loginForm').classList.add('active');
    document.getElementById('registerForm').classList.remove('active');
}

function switchToRegister() {
    document.getElementById('registerForm').classList.add('active');
    document.getElementById('loginForm').classList.remove('active');
}

function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    currentUser = { email, name: email.split('@')[0] };
    updateUserUI();
    closeAuthModal();
    showNotification('Login successful! 🎉');
}

function handleRegister(event) {
    event.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const phone = document.getElementById('registerPhone').value;
    const password = document.getElementById('registerPassword').value;

    currentUser = { email, name, phone };
    updateUserUI();
    closeAuthModal();
    showNotification('Registration successful! Welcome! 🎉');
}

function updateUserUI() {
    const userSection = document.getElementById('userSection');
    if (currentUser) {
        userSection.innerHTML = `
            <div class="user-info">
                <i class="fas fa-user-circle"></i>
                <span>${currentUser.name}</span>
            </div>
            <button class="auth-link" onclick="logout()">
                <i class="fas fa-sign-out-alt"></i> Logout
            </button>
        `;
    } else {
        userSection.innerHTML = `
            <button class="auth-link" onclick="openAuthModal('login')">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        `;
    }
}

function logout() {
    currentUser = null;
    updateUserUI();
    showNotification('Logged out successfully!');
}

// Language Functions
function changeLanguage(lang) {
    currentLanguage = lang;
    updateLanguage();
    
    // Re-render dynamic content with new language
    displayRecipes(filteredRecipes);
    displayGroceryItems(filteredGroceries);
    updateCartDisplay();
}

function updateLanguage() {
    const t = translations[currentLanguage];
    
    // Update logo
    const logo = document.querySelector('.logo');
    if (logo) {
        logo.innerHTML = `<i class="fas fa-utensils"></i> ${t.app_name}`;
    }
    
    // Update navigation
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach((link, index) => {
        const icons = ['fa-home', 'fa-book-open', 'fa-shopping-cart', 'fa-store'];
        const keys = ['home', 'recipes', 'grocery', 'store'];
        link.innerHTML = `<i class="fas ${icons[index]}"></i> ${t[keys[index]]}`;
    });
    
    // Update hero section
    const heroH1 = document.querySelector('.hero h1');
    const heroP = document.querySelector('.hero p');
    if (heroH1) heroH1.textContent = t.welcome;
    if (heroP) heroP.textContent = t.tagline;
    
    // Update CTA buttons
    const ctaButtons = document.querySelectorAll('.cta-btn');
    if (ctaButtons[0]) ctaButtons[0].innerHTML = `🔍 ${t.explore_recipes}`;
    if (ctaButtons[1]) ctaButtons[1].innerHTML = `🛒 ${t.order_groceries}`;
    
    // Update mood section
    const moodHeading = document.querySelector('.mood-section h2');
    if (moodHeading) moodHeading.textContent = `${t.mood_heading} 🎯`;
    
    const moodCards = document.querySelectorAll('.mood-card');
    const moodData = [
        { emoji: '🍲',image:'comfort.jpg', title: 'comfort_food', desc: 'comfort_desc' },
        { emoji: '⚡',image:'quickmeals.jpeg', title: 'quick_meals', desc: 'quick_desc' },
        { emoji: '🍰',image:'sweet.jpeg', title: 'sweet_tooth', desc: 'sweet_desc' },
        { emoji: '🥗',image:'healthy.jpeg', title: 'healthy_choice', desc: 'healthy_desc' }
    ];
    
    moodCards.forEach((card, index) => {
        if (moodData[index]) {
            card.innerHTML = `
                <div class="emoji">${moodData[index].emoji}</div>
                <div class="image">${moodData[index].image}</div>
                <h3>${t[moodData[index].title]}</h3>
                <p>${t[moodData[index].desc]}</p>
            `;
        }
    });
    
    // Update search section
    const searchHeading = document.querySelector('.search-section h2');
    if (searchHeading) searchHeading.textContent = `${t.recipe_explorer} 🔍`;
    
    const formLabels = document.querySelectorAll('.search-section label');
    if (formLabels[0]) formLabels[0].textContent = t.search_ingredients;
    if (formLabels[1]) formLabels[1].textContent = t.cuisine;
    
    // Update cuisine select
    const cuisineSelect = document.getElementById('cuisine');
    if (cuisineSelect) {
        cuisineSelect.innerHTML = `
            <option value="">${t.all_cuisines}</option>
            <option value="indian">${t.indian}</option>
            <option value="chinese">${t.chinese}</option>
            <option value="italian">${t.italian}</option>
            <option value="mexican">${t.mexican}</option>
        `;
    }
    
    const searchBtn = document.querySelector('.search-btn');
    if (searchBtn) searchBtn.textContent = t.search_btn;
    
    // Update cart section
    const cartHeading = document.querySelector('.cart-section h2');
    if (cartHeading) cartHeading.textContent = `🛒 ${t.your_cart}`;
    
    // Update store section
    const storeHeading = document.querySelector('.store-section h2');
    if (storeHeading) storeHeading.textContent = `🏪 ${t.grocery_store}`;
    
    const storeSearch = document.getElementById('storeSearch');
    if (storeSearch) storeSearch.placeholder = t.search_products;
    
    // Update category buttons
    const categoryBtns = document.querySelectorAll('.category-btn');
    const categories = ['all', 'vegetables', 'fruits', 'dairy', 'grains'];
    categoryBtns.forEach((btn, index) => {
        if (categories[index] && t[categories[index]]) {
            btn.textContent = t[categories[index]];
        }
    });
}

// Navigation Functions
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    
    const targetPage = document.getElementById(pageId);
    if (targetPage) targetPage.classList.add('active');
    
    const navLinks = document.querySelectorAll('.nav-link');
    const pageIndex = ['home', 'recipes', 'grocery', 'store'].indexOf(pageId);
    if (pageIndex >= 0 && navLinks[pageIndex]) {
        navLinks[pageIndex].classList.add('active');
    }
}

// Recipe Functions
function displayRecipes(recipesToDisplay) {
    const recipeGrid = document.getElementById('recipeGrid');
    if (!recipeGrid) return;
    
    const t = translations[currentLanguage];
    
    recipeGrid.innerHTML = recipesToDisplay.map(recipe => `
        <div class="recipe-card">
            <div class="recipe-image" style="background: url('${recipe.image || ''}') center/cover; $recipe.image ? 'background:linear-gradient(135deg,#FF6B35,#F7931E);':''}">
            ${!recipe.image ? recipe.emoji :''}</div>
            <div class="recipe-content">
                <h3 class="recipe-title">${recipe.name}</h3>
                <div class="recipe-meta">
                    <span><i class="fas fa-clock"></i> ${recipe.prepTime}</span>
                    <span><i class="fas fa-signal"></i> ${t[recipe.difficulty.toLowerCase()] || recipe.difficulty}</span>
                    <span><i class="fas fa-users"></i> ${recipe.servings} ${t.servings}</span>
                </div>
                <div class="recipe-actions">
                    <button class="action-btn cook-now" onclick="viewRecipe(${recipe.id})">
                        ${t.cook_now}
                    </button>
                    <button class="action-btn get-ingredients" onclick="addRecipeIngredientsToCart(${recipe.id})">
                        ${t.get_ingredients}
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function searchRecipes(event) {
    event.preventDefault();
    const ingredients = document.getElementById('ingredients').value.toLowerCase();
    const cuisine = document.getElementById('cuisine').value;
    
    filteredRecipes = recipes.filter(recipe => {
        const matchesIngredients = !ingredients || 
            recipe.ingredients.some(ing => ing.toLowerCase().includes(ingredients));
        const matchesCuisine = !cuisine || recipe.cuisine === cuisine;
        return matchesIngredients && matchesCuisine;
    });
    
    displayRecipes(filteredRecipes);
}

function filterByMood(mood) {
    filteredRecipes = recipes.filter(recipe => recipe.mood === mood);
    displayRecipes(filteredRecipes);
    showPage('recipes');
}

function viewRecipe(recipeId) {
    const recipe = recipes.find(r => r.id === recipeId);
    if (!recipe) return;
    
    const t = translations[currentLanguage];
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.style.display = 'block';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 800px;">
            <span class="close" onclick="this.parentElement.parentElement.remove()">&times;</span>
            <div style="padding:0;">${recipe.image?`<img src="${recipe.image}" alt="{recipe.name}"
                style="width:100%;height:300px;object-fit:cover;border-radius: 20px 20px 0 0;">`:`
            <div style="padding: 40px 30px;">
                <div style="text-align: center; font-size: 4rem; margin-bottom: 20px;">
                    ${recipe.emoji}
            </div>`}
                <h2 style="text-align: center; color: #2d3748; margin-bottom: 30px;">
                    ${recipe.name}
                </h2>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; text-align: center;">
                    <div>
                        <strong>${t.prep_time}:</strong><br>${recipe.prepTime}
                    </div>
                    <div>
                        <strong>${t.difficulty}:</strong><br>${t[recipe.difficulty.toLowerCase()] || recipe.difficulty}
                    </div>
                    <div>
                        <strong>${t.servings}:</strong><br>${recipe.servings}
                    </div>
                </div>
                <div style="margin-bottom: 30px;">
                    <h3 style="color: #FF6B35; margin-bottom: 15px;">Ingredients:</h3>
                    <ul style="list-style: none; padding: 0;">
                        ${recipe.ingredients.map(ing => `<li style="padding: 8px 0; border-bottom: 1px solid #eee;">✓ ${ing}</li>`).join('')}
                    </ul>
                </div>
                <div>
                    <h3 style="color: #FF6B35; margin-bottom: 15px;">Detailed Instructions:</h3>
                    <ol style="padding-left: 20px;">
                        ${recipe.detailedSteps.map(step => 
                            `<li style="padding: 10px 0; line-height: 1.6;">${step}</li>`
                        ).join('')}
                    </ol>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}
function addRecipeIngredientsToCart(recipeId) {
    const recipe = recipes.find(r => r.id === recipeId);
    if (!recipe) return;
    
    // Add basic grocery items that match recipe ingredients
    const itemsAdded = [];
    recipe.ingredients.forEach(ingredient => {
        const matchingItem = groceryItems.find(item => 
            ingredient.toLowerCase().includes(item.name.toLowerCase()) ||
            item.name.toLowerCase().includes(ingredient.split(' ')[0].toLowerCase())
        );
        if (matchingItem && !cart.find(c => c.id === matchingItem.id)) {
            addToCart(matchingItem);
            itemsAdded.push(matchingItem.name);
        }
    });
    
    if (itemsAdded.length > 0) {
        showNotification(`Added ${itemsAdded.length} items to cart!`);
        showPage('grocery');
    } else {
        showNotification('Some ingredients added to cart!');
        showPage('grocery');
    }
}

// Grocery Functions
function displayGroceryItems(itemsToDisplay) {
    const groceryGrid = document.getElementById('groceryGrid');
    if (!groceryGrid) return;
    
    const t = translations[currentLanguage];
    
    groceryGrid.innerHTML = itemsToDisplay.map(item => `
        <div class="grocery-item" onclick="addToCart(${JSON.stringify(item).replace(/"/g, '&quot;')})">
            <div class="grocery-item-header">
                <div class="grocery-item-emoji">${item.emoji}</div>
                <div>
                    <h4>${item.name}</h4>
                    <p style="color: #666; font-size: 0.9rem;">${item.unit}</p>
                </div>
            </div>
            <div class="grocery-item-footer">
                <span class="grocery-item-price">₹${item.price}</span>
                <button class="add-to-cart-btn" onclick="event.stopPropagation(); addToCart(${JSON.stringify(item).replace(/"/g, '&quot;')})">
                    ${t.add_to_cart}
                </button>
            </div>
        </div>
    `).join('');
}

function filterGroceries(category) {
    document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    if (category === 'all') {
        filteredGroceries = [...groceryItems];
    } else {
        filteredGroceries = groceryItems.filter(item => item.category === category);
    }
    displayGroceryItems(filteredGroceries);
}

function searchGroceries(searchTerm) {
    filteredGroceries = groceryItems.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    displayGroceryItems(filteredGroceries);
}

// Cart Functions
function addToCart(item) {
    const existingItem = cart.find(c => c.id === item.id);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ ...item, quantity: 1 });
    }
    updateCartDisplay();
    showNotification(`${item.name} added to cart!`);
}

function removeFromCart(itemId) {
    cart = cart.filter(item => item.id !== itemId);
    updateCartDisplay();
    showNotification('Item removed from cart');
}

function updateQuantity(itemId, change) {
    const item = cart.find(c => c.id === itemId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(itemId);
        } else {
            updateCartDisplay();
        }
    }
}

function updateCartDisplay() {
    const cartItems = document.getElementById('cartItems');
    const subtotalEl = document.getElementById('subtotal');
    const totalEl = document.getElementById('total');
    
    if (!cartItems) return;
    
    const t = translations[currentLanguage];
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div style="text-align: center; padding: 40px; color: #999;">
                <i class="fas fa-shopping-cart" style="font-size: 3rem; margin-bottom: 20px;"></i>
                <p>Your cart is empty</p>
            </div>
        `;
        if (subtotalEl) subtotalEl.textContent = '₹0';
        if (totalEl) totalEl.textContent = '₹29';
        return;
    }
    
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <div class="item-info">
                <div class="item-emoji">${item.emoji}</div>
                <div>
                    <h4>${item.name}</h4>
                    <p style="color: #666;">${item.unit}</p>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 20px;">
                <span style="font-weight: 700; color: #06FFA5;">₹${item.price * item.quantity}</span>
                <div class="quantity-controls">
                    <button class="qty-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                    <span style="font-weight: 600;">${item.quantity}</span>
                    <button class="qty-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                </div>
                <button onclick="removeFromCart(${item.id})" style="background: #ff4444; color: white; border: none; padding: 8px 12px; border-radius: 8px; cursor: pointer;">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const deliveryFee = 29;
    const total = subtotal + deliveryFee;
    
    if (subtotalEl) subtotalEl.textContent = `₹${subtotal}`;
    if (totalEl) totalEl.textContent = `₹${total}`;
    
    // Update cart summary labels
    const summaryRows = document.querySelectorAll('.summary-row');
    if (summaryRows[0]) summaryRows[0].querySelector('span').textContent = `${t.subtotal}:`;
    if (summaryRows[1]) summaryRows[1].querySelector('span').textContent = `${t.delivery}:`;
    if (summaryRows[2]) summaryRows[2].querySelector('span').textContent = `${t.total}:`;
    
    const checkoutBtn = document.querySelector('.checkout-btn');
    if (checkoutBtn) checkoutBtn.innerHTML = `${t.checkout} 🚀`;
}

function checkout() {
    if (cart.length === 0) {
        showNotification('Your cart is empty!');
        return;
    }
    
    if (!currentUser) {
        showNotification('Please login to checkout');
        openAuthModal('login');
        return;
    }
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) + 29;
    showNotification(`Order placed successfully! Total: ₹${total}`);
    cart = [];
    updateCartDisplay();
}

// Notification Function
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, #FF6B35, #F7931E);
        color: white;
        padding: 15px 30px;
        border-radius: 50px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        z-index: 10000;
        animation: slideDown 0.3s ease;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideUp 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideDown {
        from { transform: translateX(-50%) translateY(-100px); opacity: 0; }
        to { transform: translateX(-50%) translateY(0); opacity: 1; }
    }
    @keyframes slideUp {
        from { transform: translateX(-50%) translateY(0); opacity: 1; }
        to { transform: translateX(-50%) translateY(-100px); opacity: 0; }
    }
`;
document.head.appendChild(style);