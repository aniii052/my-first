javascript// Page load hote hi data load karo
async function initializeApp() {
    try {
        // Load recipes
        const recipes = await getAllRecipes();
        displayRecipes(recipes);
        
        // Load grocery items
        const groceryItems = await getAllGroceryItems();
        displayGroceryItems(groceryItems);
        
        // Load cart
        const cartItems = await getCart();
        updateCartDisplay(cartItems);
        
    } catch (error) {
        console.error('App initialization failed:', error);
        // Fallback to local data if backend fails
        displayRecipes(localRecipes); // Your existing array
    }
}

// Call on page load
document.addEventListener('DOMContentLoaded', initializeApp);